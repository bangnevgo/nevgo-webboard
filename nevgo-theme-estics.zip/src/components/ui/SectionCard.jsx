import {
  Card,
  Title,
  Text,
  Flex,
  Divider,
} from "@tremor/react";
import { cn } from "@/lib/utils";

/**
 * SectionCard — Tremor Card + Title + Text
 * Drop-in replacement untuk semua SectionCard di project.
 */
export function SectionCard({ title, subtitle, action, children, className, noPadding }) {
  const hasHeader = title || subtitle || action;
  return (
    <Card
      className={cn(
        "ring-1 ring-border/60 bg-card",
        noPadding && "[&>.tremor-Card-root]:p-0",
        className
      )}
    >
      {hasHeader && (
        <>
          <Flex justifyContent="between" alignItems="start" className="mb-1">
            <div>
              {title && (
                <Title className="text-[13px] font-semibold text-foreground leading-snug">
                  {title}
                </Title>
              )}
              {subtitle && (
                <Text className="text-[11px] text-muted-foreground mt-0.5">
                  {subtitle}
                </Text>
              )}
            </div>
            {action && <div className="shrink-0">{action}</div>}
          </Flex>
          <Divider className="my-3 border-border/60" />
        </>
      )}
      {children}
    </Card>
  );
}

/**
 * CardTitle2 — inline header pakai Tremor Title + Text
 * Dipakai di dalam page-level sections tanpa full card wrapper.
 */
export function CardTitle2({ title, sub, action }) {
  return (
    <Flex justifyContent="between" alignItems="start" className="mb-4">
      <div>
        <Title className="text-[13px] font-semibold text-foreground leading-snug">
          {title}
        </Title>
        {sub && (
          <Text className="text-[11px] text-muted-foreground mt-0.5">
            {sub}
          </Text>
        )}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </Flex>
  );
}

export { CardTitle2 as CardTitle };

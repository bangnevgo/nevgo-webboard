import {
  Card,
  Metric,
  Text,
  Flex,
  BadgeDelta,
} from "@tremor/react";
import { cn } from "@/lib/utils";
import { MoreHorizontal } from "lucide-react";

/**
 * MetricCard — Tremor Card + Metric + BadgeDelta
 *
 * @param {string}  title
 * @param {string}  value         — formatted string e.g. "Rp 48.3M"
 * @param {string}  sub           — supporting line below value
 * @param {number}  trend         — numeric %, positive = up
 * @param {boolean} trendInverse  — flip good/bad semantics (e.g. bounce rate)
 * @param {ReactNode} children    — optional slot (sparkline, chart, etc)
 */
export function MetricCard({
  title,
  value,
  sub,
  trend,
  trendInverse = false,
  children,
  className,
}) {
  const getDeltaType = () => {
    if (trend === undefined || trend === null || trend === 0) return "unchanged";
    const isGood = trendInverse ? trend < 0 : trend > 0;
    return isGood ? "moderateIncrease" : "moderateDecrease";
  };

  const trendLabel =
    trend != null && trend !== 0
      ? `${trend > 0 ? "+" : ""}${trend}% vs last period`
      : undefined;

  return (
    <Card
      className={cn(
        "ring-1 ring-border/60 bg-card",
        "hover:ring-border transition-all duration-150",
        className
      )}
    >
      {/* Title row */}
      <Flex justifyContent="between" alignItems="start" className="mb-3">
        <Text className="text-[12px] font-medium text-muted-foreground leading-tight">
          {title}
        </Text>
        <button className="w-5 h-5 flex items-center justify-center rounded text-muted-foreground/40 hover:text-muted-foreground hover:bg-muted transition-colors -mr-1 shrink-0">
          <MoreHorizontal size={13} />
        </button>
      </Flex>

      {/* Value — Tremor Metric */}
      <Metric className="text-foreground text-[22px] font-semibold tracking-tight leading-none tabular-nums">
        {value ?? "—"}
      </Metric>

      {/* Trend BadgeDelta + sub */}
      <Flex justifyContent="start" alignItems="center" className="gap-2 mt-2 flex-wrap">
        {trendLabel && (
          <BadgeDelta
            deltaType={getDeltaType()}
            size="xs"
            className="text-[10.5px] font-medium"
          >
            {trendLabel}
          </BadgeDelta>
        )}
        {sub && (
          <Text className="text-[11px] text-muted-foreground leading-tight">
            {sub}
          </Text>
        )}
      </Flex>

      {children && <div className="mt-3">{children}</div>}
    </Card>
  );
}

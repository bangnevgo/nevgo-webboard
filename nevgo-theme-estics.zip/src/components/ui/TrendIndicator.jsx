import { BadgeDelta } from "@tremor/react";
import { cn } from "@/lib/utils";

/**
 * TrendIndicator — Tremor BadgeDelta wrapper
 * Dipakai di MetricCard dan tempat lain yang butuh inline trend display.
 *
 * @param {number}  value    — numeric %, positive = up
 * @param {boolean} inverse  — flip semantics (e.g. bounce rate: up = bad)
 */
export function TrendIndicator({ value, inverse = false, className }) {
  if (value === undefined || value === null) return null;

  if (value === 0) {
    return (
      <BadgeDelta
        deltaType="unchanged"
        size="xs"
        className={cn("text-[10.5px] font-medium", className)}
      >
        0%
      </BadgeDelta>
    );
  }

  const isGood = inverse ? value < 0 : value > 0;
  const deltaType = isGood ? "moderateIncrease" : "moderateDecrease";
  const sign = value > 0 ? "+" : "";

  return (
    <BadgeDelta
      deltaType={deltaType}
      size="xs"
      className={cn("text-[10.5px] font-medium tabular-nums", className)}
    >
      {sign}{value}%
    </BadgeDelta>
  );
}

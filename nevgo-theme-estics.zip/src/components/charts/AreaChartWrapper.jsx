import { AreaChart } from "@tremor/react";

const COLOR_MAP = {
  "#8B5CF6": "violet",
  "#7c3aed": "violet",
  "#06B6D4": "cyan",
  "#10B981": "emerald",
  "#F59E0B": "amber",
  "#EF4444": "red",
  "#ef4444": "red",
  "#3B82F6": "blue",
  "#EC4899": "pink",
  "#14B8A6": "teal",
  "#22d3ee": "cyan",
  "#a78bfa": "violet",
  "#fb923c": "orange",
};

/**
 * AreaChartWrapper — Tremor AreaChart wrapper
 * @param {Array}  data      - array of objects
 * @param {Array}  series    - [{ key: string, color: hex }]
 * @param {number} height    - tinggi chart dalam px
 * @param {string} index     - key untuk sumbu X (default "day")
 * @param {Function} formatter - value formatter
 */
export function AreaChartWrapper({ data, series, height = 200, index = "day", formatter }) {
  const categories = series.map((s) => s.key);
  const colors = series.map((s) => COLOR_MAP[s.color] || "blue");

  return (
    <div style={{ height: `${height}px` }}>
      <AreaChart
        data={data}
        index={index}
        categories={categories}
        colors={colors}
        valueFormatter={formatter}
        showLegend={false}
        showGridLines={true}
        showXAxis={true}
        showYAxis={true}
        className="h-full"
        curveType="natural"
      />
    </div>
  );
}

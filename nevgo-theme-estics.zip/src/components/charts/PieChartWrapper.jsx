import { DonutChart, Legend } from "@tremor/react";

const COLOR_MAP = {
  "#8B5CF6": "violet", "#7c3aed": "violet",
  "#06B6D4": "cyan",   "#22d3ee": "cyan",
  "#10B981": "emerald","#F59E0B": "amber",
  "#EF4444": "red",    "#ef4444": "red",
  "#3B82F6": "blue",   "#EC4899": "pink",
  "#14B8A6": "teal",   "#a78bfa": "violet",
  "#fb923c": "orange",
};

const DEFAULT_COLORS = ["violet", "cyan", "emerald", "amber", "red", "pink", "teal", "orange"];

/**
 * PieChartWrapper — Tremor DonutChart wrapper
 * @param {Array}    data      - array of objects
 * @param {string}   dataKey   - key untuk nilai
 * @param {string}   nameKey   - key untuk nama
 * @param {number}   height    - tinggi dalam px
 * @param {boolean}  showLegend
 * @param {Function} formatter
 */
export function PieChartWrapper({
  data,
  dataKey = "value",
  nameKey = "name",
  height = 200,
  showLegend = false,
  formatter,
}) {
  const chartData = data.map((item) => ({
    name: item[nameKey] || item.name,
    value: item[dataKey] || item.value,
  }));

  const colors = data.map((item) =>
    item.color ? COLOR_MAP[item.color] || "blue" : null
  );

  const resolvedColors = colors.every(Boolean) ? colors : DEFAULT_COLORS;

  return (
    <div style={{ height: `${height}px` }} className="flex flex-col items-center justify-center gap-3">
      <DonutChart
        data={chartData}
        category="value"
        index="name"
        valueFormatter={formatter}
        colors={resolvedColors}
        showLabel={true}
        showAnimation={true}
        className="h-full w-full"
      />
      {showLegend && (
        <Legend
          categories={chartData.map((d) => d.name)}
          colors={resolvedColors}
          className="text-xs"
        />
      )}
    </div>
  );
}

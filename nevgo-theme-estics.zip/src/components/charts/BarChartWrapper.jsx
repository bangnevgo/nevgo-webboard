import { BarChart } from "@tremor/react";

const COLOR_MAP = {
  "#8B5CF6": "violet", "#7c3aed": "violet",
  "#06B6D4": "cyan",   "#22d3ee": "cyan",
  "#10B981": "emerald","#F59E0B": "amber",
  "#EF4444": "red",    "#ef4444": "red",
  "#3B82F6": "blue",   "#EC4899": "pink",
  "#14B8A6": "teal",   "#a78bfa": "violet",
  "#fb923c": "orange",
};

/**
 * BarChartWrapper — Tremor BarChart wrapper
 * @param {Array}   data      - array of objects
 * @param {Array}   series    - [{ key: string, color: hex }]
 * @param {number}  height    - tinggi chart dalam px
 * @param {string}  layout    - "horizontal" (default) | "vertical"
 * @param {string}  index     - key untuk sumbu X
 * @param {Function} formatter
 */
export function BarChartWrapper({
  data,
  series,
  height = 200,
  layout = "horizontal",
  index,
  formatter,
}) {
  const isVertical = layout === "vertical";
  const categories = series.map((s) => s.key);
  const colors = series.map((s) => COLOR_MAP[s.color] || "blue");
  const resolvedIndex = index || (isVertical ? "name" : "day");

  return (
    <div style={{ height: `${height}px` }}>
      <BarChart
        data={data}
        index={resolvedIndex}
        categories={categories}
        colors={colors}
        valueFormatter={formatter}
        layout={isVertical ? "horizontal" : "vertical"}
        showLegend={false}
        showGridLines={true}
        showXAxis={true}
        showYAxis={true}
        className="h-full"
      />
    </div>
  );
}

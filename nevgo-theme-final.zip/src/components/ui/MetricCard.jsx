import { BadgeDelta } from "@tremor/react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { MoreHorizontal } from "lucide-react";

/**
 * MetricCard
 * Layout: shadcn Card (respects CSS variables, dark mode native)
 * Trend:  Tremor BadgeDelta (no manual equivalent)
 */
export function MetricCard({
  title,
  value,
  sub,
  trend,
  trendInverse = false,
  children,
  className,
}) {
  const getDeltaType = () => {
    if (trend === undefined || trend === null || trend === 0) return "unchanged";
    const isGood = trendInverse ? trend < 0 : trend > 0;
    return isGood ? "moderateIncrease" : "moderateDecrease";
  };

  const trendLabel =
    trend != null && trend !== 0
      ? `${trend > 0 ? "+" : ""}${trend}%`
      : undefined;

  return (
    <Card className={cn(
      "bg-card border border-border rounded-xl",
      "hover:border-border/80 transition-colors duration-150",
      className
    )}>
      <CardContent className="px-5 py-4">
        {/* Title + menu */}
        <div className="flex items-center justify-between mb-3">
          <p className="text-[12px] font-medium text-muted-foreground leading-tight">
            {title}
          </p>
          <button className="w-5 h-5 flex items-center justify-center rounded text-muted-foreground/30 hover:text-muted-foreground hover:bg-muted transition-colors -mr-1">
            <MoreHorizontal size={12} />
          </button>
        </div>

        {/* Value */}
        <p className="text-[22px] font-semibold text-foreground tracking-tight leading-none tabular-nums">
          {value ?? "—"}
        </p>

        {/* Trend + sub */}
        <div className="flex items-center gap-2 mt-2 flex-wrap">
          {trendLabel && (
            <BadgeDelta
              deltaType={getDeltaType()}
              size="xs"
            >
              {trendLabel}
            </BadgeDelta>
          )}
          {sub && (
            <p className="text-[11px] text-muted-foreground leading-tight">
              {sub}
            </p>
          )}
        </div>

        {children && <div className="mt-3">{children}</div>}
      </CardContent>
    </Card>
  );
}

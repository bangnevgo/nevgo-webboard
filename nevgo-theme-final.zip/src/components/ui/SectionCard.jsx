import { Divider } from "@tremor/react";
import {
  Card, CardContent, CardHeader,
  CardTitle, CardDescription,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";

/**
 * SectionCard
 * Layout: shadcn Card (CSS variables, dark mode native)
 * Divider: Tremor Divider
 */
export function SectionCard({ title, subtitle, action, children, className, noPadding }) {
  const hasHeader = title || subtitle || action;
  return (
    <Card className={cn("border-border bg-card", className)}>
      {hasHeader && (
        <CardHeader className="px-5 pt-5 pb-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              {title && (
                <CardTitle className="text-[13px] font-semibold text-foreground leading-snug">
                  {title}
                </CardTitle>
              )}
              {subtitle && (
                <CardDescription className="text-[11px] mt-0.5">
                  {subtitle}
                </CardDescription>
              )}
            </div>
            {action && <div className="shrink-0">{action}</div>}
          </div>
          <Divider className="mt-4 mb-0 border-border/60" />
        </CardHeader>
      )}
      <CardContent className={cn(
        noPadding ? "p-0" : "px-5 pb-5",
        hasHeader ? "pt-4" : "pt-5"
      )}>
        {children}
      </CardContent>
    </Card>
  );
}

export function CardTitle2({ title, sub, action }) {
  return (
    <div className="flex items-start justify-between gap-2 mb-4">
      <div>
        <p className="text-[13px] font-semibold text-foreground leading-snug">{title}</p>
        {sub && <p className="mt-0.5 text-[11px] text-muted-foreground">{sub}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

export { CardTitle2 as CardTitle };
